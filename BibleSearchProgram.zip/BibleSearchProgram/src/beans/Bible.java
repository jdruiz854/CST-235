package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean
@ViewScoped
public class Bible 
{
	private int chapter;
	private String bookName;
	private int verseNumber; 
	private String word;
	
	public Bible() 
	{
		
	}
	
	public Bible(int chapter, String bookName, int verseNumber, String word)
	{
		this.chapter = chapter;
		this.bookName = bookName;
		this.verseNumber = verseNumber;
		this.word = word;
	}

	public int getVerseNumber() {
		return verseNumber;
	}

	public void setVerseNumber(int verseNumber) {
		this.verseNumber = verseNumber;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public int getChapter() {
		return chapter;
	}

	public void setChapter(int chapter) {
		this.chapter = chapter;
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}
	
}
