package business;

import javax.faces.bean.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@RequestScoped
@Path("/bible")
@Produces({"application/xml", "application/json"})
@Consumes({"application/xml", "application/json"})
public class BibleRestService implements BibleSearchInterface
{	
	@Inject
	BibleSearchInterface service;
	
	@GET
	@Path("/getjson")
	@Override
	public String searchWord(String word) throws Exception {
		// TODO Auto-generated method stub
		return  service.searchWord(word);
	}

	@GET
	@Path("/getxml")
	@Override
	public int countWord(String word) throws Exception {
		// TODO Auto-generated method stub
		return  service.countWord(word);
	}

}
