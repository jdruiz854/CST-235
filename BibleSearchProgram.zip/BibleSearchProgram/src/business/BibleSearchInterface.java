package business;

import javax.ejb.Local;

@Local
public interface BibleSearchInterface 
{

	String searchWord(String word) throws Exception;
	int countWord(String word) throws Exception;
	
}
