package business;

import java.io.BufferedReader;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import data.DataService;
import beans.Bible;

@Stateless
@Local (BibleSearchInterface.class)
@Alternative
public class BibleSearchService implements BibleSearchInterface
{	
	
	Bible b = new Bible();
	
	@Override
	@SuppressWarnings("unlikely-arg-type")
	public String searchWord(String word) throws Exception
	{
		int length;
		String result = null;
		
		BufferedReader bible = new DataService().bibleDatabase();
		
		length = bible.toString().length();
		
		for(int i = 0; i < length; i++)
		{
			if (bible.equals(word))	
			{
				 result = ("Book: " + b.getBookName() + "Chapter: " + b.getChapter() + "Verse: " + b.getVerseNumber());
			}
		}
		return result;
	}
	
	@Override
	@SuppressWarnings("unlikely-arg-type")
	public int countWord(String word) throws Exception
	{
		int length;
		BufferedReader bible = new DataService().bibleDatabase();
		int count = 0;
		
		length = bible.toString().length();
		
		for(int i = 0; i < length; i++)
		{
			if(bible.equals(word))
			{
				count++;
			}
		}		
	
		return count;
	}

}


















