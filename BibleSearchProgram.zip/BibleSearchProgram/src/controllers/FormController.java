package controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;

import business.BibleSearchInterface;

@ManagedBean
@ViewScoped
public class FormController 
{
	@Inject
	BibleSearchInterface services;
	
	public BibleSearchInterface getSearch()
	{
		return services;
	}
	
	public String searchButton()
	{
		return "ResponsePage.xhtml";
	}
	
	public String cancelButton()
	{
		return "inputForm.xhtml";
	}
	
	public void countWords(String word) throws Exception
	{
		services.countWord(word);
	}
	
	public void searchWords(String word) throws Exception
	{
		services.searchWord(word);
	}
}
