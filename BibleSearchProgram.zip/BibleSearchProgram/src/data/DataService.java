package data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class DataService
{
	public BufferedReader bibleDatabase () throws Exception
	{	
		File file = new File("C:\\Users\\" + System.getProperty("user.name")+ "\\Desktop\\bible.txt");
		
		BufferedReader br = new BufferedReader(new FileReader(file));
		
		return br;
	}
}
