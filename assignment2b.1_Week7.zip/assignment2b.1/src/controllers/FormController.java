package controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import beans.Order;
import beans.User;
import business.MyTimerService;
import business.OrderBusinessInterface;

@ManagedBean
@ViewScoped
public class FormController 
{
	@Inject
	OrderBusinessInterface services;
	
	@EJB
	MyTimerService timer;
	

	private void insertOrder() throws SQLException
	{
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "Tetelestai";
		
		String var = "INSERT INTO testapp.ORDERS(ORDER_NUMBER, PRODUCT_NAME, PRICE, QUANTITY) VALUES('001122334455', 'This was inserted new', 25.00, 100)";
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
	try 
		{
			conn = DriverManager.getConnection(url, username, password);
			System.out.println("Success!");		
			
			stmt = conn.createStatement();
			
			rs = stmt.executeQuery(var);
						
			
		} 
			catch (SQLException e)
		{
			e.printStackTrace();
			System.out.println("Failure!");
		} 
		finally
		{
			rs.close();
			stmt.close();
			conn.close();
		}
	}
	
	private void getAllOrders() throws SQLException
	{
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "Tetelestai";
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
	try 
		{
			conn = DriverManager.getConnection(url, username, password);
			System.out.println("Success!");		
			
			stmt = conn.createStatement();
			
			rs = stmt.executeQuery("Select * from testapp.orders");
			
			while (rs.next())
			{
				System.out.println("id = " + rs.getInt("id") + " Order Numbre: " + rs.getString("order_no") + " Product Name: " + rs.getString("product_name") + " Price: " + 
									rs.getString("price") + " Quantity: " + rs.getString("quantity"));
			}
			
			
		} 
			catch (SQLException e)
		{
			e.printStackTrace();
			System.out.println("Failure!");
		} 
		finally
		{
			rs.close();
			stmt.close();
			conn.close();
		}
	
	}
	
	public OrderBusinessInterface getService()
	{
		return services;
		
	}
	
	public String onSendOrder(Order order)
	{
		services.sendOrder(order);
		return "OrderResponse.xhtml";
	}
	
	public String onLogoff()
	{
		// Invalidate the Session to clear the security token
		FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
			
		// Redirect to a protected page (so we get a full HTTP Request) to get Login Page
		return "TestResponse.xhtml?faces-redirect=true";

	}
	
}
