package controllers;

import javax.ejb.EJB;
import javax.inject.Inject;

import business.MyTimerService;
import business.OrdersBusinessInterface;
import business.OrdersBusinessService;

public class FormController
{
	@Inject
	private OrdersBusinessInterface ordersBusinessInterface;
	
	@EJB
	private MyTimerService myTimerService;
	
	
	public void onSubmit()
	{
		OrdersBusinessInterface.test();
		MyTimerService.setTimer(1000);
	}

	public void getService()
	{
		ordersBusinessInterface.getClass();
	}
	
}
